<?php

return [
    'join_meeting' => 'Join the Meeting',
    'failed_create_google_meet_link' => 'Failed to create Google Meet link',
];
