<?php

namespace Modules\LaraPayease\Database\Seeders;

use Illuminate\Database\Seeder;

class LaraPayeaseDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
    }
}
